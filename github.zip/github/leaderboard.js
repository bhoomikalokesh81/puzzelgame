[
    {
        id: "1",
        level: "2",
        score: "1",
        name: "Bhoomi",
    },
    {
        id: "2",
        level: "3",
        score: "6",
        name: "Bhoomi",
    },
    {
        id: "3",
        level: "4",
        score: "60",
        name: "Bhoomi",
    },
    {
        id: "4",
        level: "5",
        score: "194",
        name: "Bhoomi",
    },
    {
        id: "5",
        level: "6",
        score: "359",
        name: "Bhoomi",
    },
    {
        id: "6",
        level: "7",
        score: "689",
        name: "Bhoomi",
    },
    {
        id: "7",
        level: "8",
        score: "1147",
        name: "Bhoomi",
    },
    {
        id: "8",
        level: "9",
        score: "1760",
        name: "Bhoomi",
    },
];